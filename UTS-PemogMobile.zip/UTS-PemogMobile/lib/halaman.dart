import 'package:flutter/material.dart';

class Halaman extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: new Text("Jurusan"),
      ),
      body: new Container(
        child: GridView.count(
          crossAxisCount: 2,
          children: <Widget>[
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/ti.png',
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/si.jpg',
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/sk.jpg',
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/hospar.png',
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/dkv2.png',
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/fismed2.png',
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/manajemen.jpg',
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              alignment: Alignment.center,
              child: Image.asset(
                'images/akutansi21.jpg',
              ),
            ),
          ],
        ),
      ),
    );
  }
}